var config = {
    map: {
        '*' : {
            'Mageplaza_Productslider/js/owl.carousel' : 'Mageplaza_Productslider/js/owl.carousel',
            'Mageplaza_Productslider/js/owl.carousel.min' : 'Mageplaza_Productslider/js/owl.carousel.min'
        }
    }
};