var config = {
    map: {
        '*' : {
            'Mageplaza_Productslider/js/owl.carousel' : 'Mageplaza_Productslider/js/owl.carousel',
            'Mageplaza_Productslider/js/owl.carousel.min' : 'Mageplaza_Productslider/js/owl.carousel.min'
        }
    },
    shim: {
        'Mageplaza_Productslider/js/owl.carousel' : ['jquery','jquery/ui'],
        'Mageplaza_Productslider/js/owl.carousel.min' : ['jquery','jquery/ui']
    }
};
